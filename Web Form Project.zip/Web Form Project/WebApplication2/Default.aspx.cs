﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //message text
            if (TextBox1.Text == "" || TextBox2.Text == "") return;

            //new message
            string headcolor = "navy";
            string head = "<font color='" + headcolor + "'><b> Added on " + DateTime.Now.ToString() + "</b></font>";
            string message = TextBox2.Text.Trim().Replace("\n", "<br />");
            string nickname = "<i>" + TextBox1.Text + "</i> ("+ this.Request.UserHostAddress + ")" ;

            //adding message
            string newMessage = head + "<br />" + message + "<br />" + nickname + "<br />";
            Label4.Text += newMessage;

            //smth in polish
            TextBox2.Text = "";


        }
    }
}